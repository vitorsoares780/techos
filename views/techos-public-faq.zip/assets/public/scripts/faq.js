/* ============================================================
   TechOS — Comportamentos da página de FAQ
   ============================================================ */
(function () {
  "use strict";

  const faqList = document.querySelector("[data-faq-list]");
  if (!faqList) {
    return;
  }

  const details = Array.from(faqList.querySelectorAll("details"));

  details.forEach(function (item) {
    item.addEventListener("toggle", function () {
      if (!item.open) {
        return;
      }

      details.forEach(function (other) {
        if (other !== item && other.open) {
          other.open = false;
        }
      });
    });
  });
})();
